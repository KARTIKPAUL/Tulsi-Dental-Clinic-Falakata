import React from 'react';

const MedicalHistory = ({ value, onChange }) => (
  <div>
    <label htmlFor="medicalHistory" className="block text-gray-600 mb-1">
      Medical History:<span style={{ color: 'red' }}>*</span>
    </label>
    <textarea
      id="medicalHistory"
      name="medicalHistory"
      value={value}
      onChange={onChange}
      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
      rows="4"
    />
  </div>
);

export default MedicalHistory;
