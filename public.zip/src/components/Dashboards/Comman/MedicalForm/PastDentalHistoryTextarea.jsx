import React from 'react';

const PastDentalHistoryTextarea = ({ value, onChange }) => (
  <div>
    <label htmlFor="pastDentalHistory" className="block text-gray-600 mb-1">
      Past Dental History:<span style={{ color: 'red' }}>*</span>
    </label>
    <textarea
      id="pastDentalHistory"
      name="pastDentalHistory"
      value={value}
      onChange={onChange}
      className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
      rows="4"
    />
  </div>
);

export default PastDentalHistoryTextarea;
