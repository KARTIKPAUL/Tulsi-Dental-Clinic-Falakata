// src/components/UsersList.js  

import React, { useState, useEffect } from 'react'; 
import { FaChevronDown, FaChevronUp, FaEdit, FaTrash, FaSearch } from 'react-icons/fa'; // Added FaSearch
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Spinner from '../../Spinner';
import API from '../../../services/api';
import Loading from '../../Loading';

const UserList = () => {
  const navigate = useNavigate(); // Initialize useNavigate

  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]); // Added state for filtered users
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [checkupInfo, setCheckupInfo] = useState("");
  const [age, setAge] = useState(0);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);


  // State to manage which tiles are expanded
  const [expandedTiles, setExpandedTiles] = useState({});

  // State for search term
  const [searchTerm, setSearchTerm] = useState('');

  // Helper function to calculate age from date of birth
  const calculateAge = (dateOfBirth) => {
    const dob = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDifference = today.getMonth() - dob.getMonth();

    // Adjust age if the birthday hasn't occurred yet this year
    if (
      monthDifference < 0 ||
      (monthDifference === 0 && today.getDate() < dob.getDate())
    ) {
      age--;
    }

    return age;
  };

  // Fetch all users on component mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await API.get(`${process.env.REACT_APP_API_URL}/api/doctor/get-all-users`, {
         
        });
        setUsers(response.data);
        setFilteredUsers(response.data); // Initialize filtered users
        setLoading(false);
      } catch (err) {
        console.error('Error fetching users:', err);
        setError(err.response && err.response.data.message ? err.response.data.message : 'Failed to load users.');
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // Handle search input change
  const handleSearch = (e) => {
    const term = e.target.value;
    setSearchTerm(term);

    if (term.trim() === '') {
      setFilteredUsers(users);
    } else {
      const lowerCaseTerm = term.toLowerCase();
      const filtered = users.filter((user) => {
        // Adjust the fields you want to search through
        const email = user.email.toLowerCase();
        const name = user.userDetails?.name?.toLowerCase() || '';
        const role = user.role.toLowerCase();
        return (
          email.includes(lowerCaseTerm) ||
          name.includes(lowerCaseTerm) ||
          role.includes(lowerCaseTerm)
        );
      });
      setFilteredUsers(filtered);
    }
  };

  // Toggle the expansion of a user tile
  const toggleTile = (id) => {
    setExpandedTiles((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const openModal = (user) => {
    setSelectedUser(user);
    if (user.userDetails?.dateOfBirth) {
      const userAge = calculateAge(user.userDetails.dateOfBirth);
      setAge(userAge);
    } else {
      setAge('N/A'); // Handle cases where DOB is missing
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setCheckupInfo('');
    setAge(0); // Reset age if necessary
  };

  const handleSubmit = async () => {
    if (!checkupInfo.trim()) {
      toast.error('Chief complaint is required.');
      return;
    }

    try {
      const response = await API.post(`${process.env.REACT_APP_API_URL}/api/doctor/existing-user-opd`, {
        age: typeof age === 'number' ? age : null, // Ensure age is a number
        checkupInfo,
        user: selectedUser._id,
        medicalDetails: selectedUser.medicalDetails._id,
        userDetails: selectedUser.userDetails._id,
      });

      toast.success('OPD Created successfully!', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: 'dark',
      });

      closeModal();
    } catch (error) {
      setError(error.response?.data?.message || 'Something went wrong!');
      toast.error(error.response?.data?.message || 'Something went wrong!', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        theme: 'dark',
      });
      closeModal();
    }
  };

  // Handle editing a user
  const handleEdit = (id) => {
    navigate(`/dashboard/edit-user/${id}`); // Adjust the route as needed
  };

  const handleOPDCreate = async (user) => { // Declare function as async
    console.log("user: ", user)
    try {
      const userAge = calculateAge(user.userDetails.dateOfBirth);
      const response = await API.post(`${process.env.REACT_APP_API_URL}/api/doctor/existing-user-opd`, {
        age: userAge,
        checkupInfo,
        user: user._id,
        medicalDetails: user.medicalDetails._id,
        userDetails: user.userDetails._id,
      });


      navigate(`/dashboard/checkup/${response.data}`);

    } catch (error) {
      setError(error.response?.data?.message || 'Something went wrong!');
    }
  };


  // Handle deleting a user
  const handleDelete = async (id) => {
    const confirmDelete = window.confirm('Are you sure you want to delete this user? This action cannot be undone.');
    if (!confirmDelete) return;

    try {
      const token = localStorage.getItem('token'); // Adjust based on how you store the token
      await API.delete(`${process.env.REACT_APP_API_URL}/api/users/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Remove the deleted user from both users and filteredUsers states
      setUsers((prevUsers) => prevUsers.filter((user) => user._id !== id));
      setFilteredUsers((prevUsers) => prevUsers.filter((user) => user._id !== id));

      toast.success('User deleted successfully!', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        theme: 'colored',
      });
    } catch (err) {
      console.error('Error deleting user:', err);
      toast.error(err.response && err.response.data.message ? err.response.data.message : 'Failed to delete user.', {
        position: 'top-center',
        autoClose: 3000,
        hideProgressBar: true,
        theme: 'colored',
      });
    }
  };

  if (loading) {
    return (
      <Loading/>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-50">
        <div className="text-red-500 text-xl">{error}</div>
      </div>
    );
  }

  // Animation variants for the tile expansion
  const variants = {
    collapsed: { height: 0, opacity: 0, overflow: 'hidden' },
    expanded: { height: 'auto', opacity: 1 },
  };

  // Animation variants for the tile container
  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.05 },
    }),
  };

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <div className="mx-auto p-6 bg-white shadow-md rounded-lg ">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">All Patients</h1>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative">
            <FaSearch className="absolute top-3 left-3 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={handleSearch}
              placeholder="Search by email, name, or role..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="space-y-6">
          {filteredUsers.length > 0 ? (
            filteredUsers.filter(user => user.role === "patient").map((user, index) => (
              <motion.div
                key={user._id}
                className="bg-white border border-gray-200 rounded-lg shadow-sm"
                initial="hidden"
                animate="visible"
                custom={index}
                variants={containerVariants}
              >
                {/* Header */}
                <div
                  className="flex justify-between items-center p-4 cursor-pointer"
                  onClick={() => toggleTile(user._id)}
                >
                  <div>
                    <p className="text-xl font-semibold text-gray-800">
                      Name: <span className="text-blue-600">{user.userDetails?.name || 'N/A'}</span>
                    </p>
                    <p className="text-md text-gray-600">
                      <span className="font-medium">Email:</span> {user.email}
                    </p>
                    <p className="text-md text-gray-600">
                      <span className="font-medium">Account Status:</span> {user.status.charAt(0).toUpperCase() + user.status.slice(1)}
                    </p>
                    <p className="text-md text-gray-600">
                      <span className="font-medium">Created At: </span>{new Date(user.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    {expandedTiles[user._id] ? (
                      <FaChevronUp className="h-6 w-6 text-gray-600" />
                    ) : (
                      <FaChevronDown className="h-6 w-6 text-gray-600" />
                    )}
                  </div>
                </div>

                {/* Expanded Content with Animation */}
                <AnimatePresence>
                  {expandedTiles[user._id] && (
                    <motion.div
                      className="px-4 pb-4"
                      initial="collapsed"
                      animate="expanded"
                      exit="collapsed"
                      variants={variants}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                    >
                      <div className="mt-4 border-t pt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {/* User Details */}
                          <div>
                            <h2 className="text-lg font-semibold mb-2 text-gray-700">User Details</h2>
                            <div className="space-y-1 text-gray-600">
                              <p>
                                <span className="font-medium">Name:</span> {user.userDetails?.name || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Gender:</span> {user.userDetails?.gender || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Date of Birth:</span>{' '}
                                {user.userDetails?.dateOfBirth
                                  ? new Date(user.userDetails.dateOfBirth).toLocaleDateString()
                                  : 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Age:</span> {user.userDetails?.dateOfBirth ? calculateAge(user.userDetails.dateOfBirth) : 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Contact:</span> {user.userDetails?.contact?.mobile || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Email:</span> {user.userDetails?.contact?.email || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Address:</span> {user.userDetails?.contact?.address || 'N/A'}
                              </p>
                            </div>
                            <br /><br />
                            {/* Emergency Contact */}
                            <div>
                              <h2 className="text-lg font-semibold mb-2 text-gray-700">Emergency Contact</h2>
                              <div className="space-y-1 text-gray-600">
                                <p>
                                  <span className="font-medium">Name:</span> {user.userDetails?.emergencyContact?.name || 'N/A'}
                                </p>
                                <p>
                                  <span className="font-medium">Relationship:</span> {user.userDetails?.emergencyContact?.relationship || 'N/A'}
                                </p>
                                <p>
                                  <span className="font-medium">Phone:</span> {user.userDetails?.emergencyContact?.phone || 'N/A'}
                                </p>
                              </div>
                            </div>
                          </div>
                          
                          {/* Medical Details */}
                          <div>
                            <h2 className="text-lg font-semibold mb-2 text-gray-700">Medical Details</h2>
                            <div className="space-y-1 text-gray-600">
                              <p>
                                <span className="font-medium">Blood Group:</span> {user.medicalDetails?.bloodGroup || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Medical History:</span> {user.medicalDetails?.medicalHistory || 'N/A'}
                              </p>
                              <div>
                                <span className="font-medium">Medications:</span>
                                {user.medicalDetails?.medications && user.medicalDetails.medications.length > 0 ? (
                                  <ul className="list-disc list-inside ml-4">
                                    {user.medicalDetails.medications.map((med, idx) => (
                                      <li key={idx}>
                                        {med.name} - {med.dosage} - {med.frequency}
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <p className="ml-4">No medications listed.</p>
                                )}
                              </div>
                              <div>
                                <span className="font-medium">Allergies:</span>
                                {user.medicalDetails?.allergies && user.medicalDetails.allergies.length > 0 ? (
                                  <ul className="list-disc list-inside ml-4">
                                    {user.medicalDetails.allergies.map((allergy, idx) => (
                                      <li key={idx}>
                                        {allergy.allergen} - {allergy.reaction} ({allergy.severity})
                                      </li>
                                    ))}
                                  </ul>
                                ) : (
                                  <p className="ml-4">No allergies listed.</p>
                                )}
                              </div>
                              <div>
                                <span className="font-medium">Lifestyle & Habits:</span>
                                <ul className="list-disc list-inside ml-4">
                                  <li>
                                    Smoking Status: {user.medicalDetails?.lifestyleAndHabits?.smokingStatus || 'N/A'}
                                  </li>
                                  <li>
                                    Alcohol Use: {user.medicalDetails?.lifestyleAndHabits?.alcoholUse || 'N/A'}
                                  </li>
                                  <li>
                                    Tobacco: {user.medicalDetails?.lifestyleAndHabits?.tobacco || 'N/A'}
                                  </li>
                                </ul>
                              </div>
                              <p>
                                <span className="font-medium">Past Dental History:</span> {user.medicalDetails?.pastDentalHistory || 'N/A'}
                              </p>
                              <p>
                                <span className="font-medium">Notes:</span> {user.medicalDetails?.notes || 'No additional notes.'}
                              </p>
                            </div>
                          </div>

                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">

                          {/* Financial Details */}
                          {/* <div>
                                                    <h2 className="text-lg font-semibold mb-2 text-gray-700">Financial Details</h2>
                                                    <div className="space-y-1 text-gray-600">
                                                        <p>
                                                            <span className="font-medium">Total Cost:</span> ${user.financials?.totalCost || 0}
                                                        </p>
                                                        <p>
                                                            <span className="font-medium">Number of Visits:</span> {user.financials?.numberOfVisits || 0}
                                                        </p>
                                                        <p>
                                                            <span className="font-medium">Cost Per Visit:</span> ${user.financials?.costPerVisit || 0}
                                                        </p>
                                                        <p>
                                                            <span className="font-medium">Remaining Cost Per Visit:</span> ${user.financials?.remainingCostPerVisit || 0}
                                                        </p>
                                                        <div>
                                                            <span className="font-medium">Visits:</span>
                                                            {user.financials?.visits && user.financials.visits.length > 0 ? (
                                                                <ul className="list-disc list-inside ml-4">
                                                                    {user.financials.visits.map((visit, idx) => (
                                                                        <li key={idx}>
                                                                            {visit.treatmentDone} - ${visit.amount} - {visit.notes || 'No notes'}
                                                                        </li>
                                                                    ))}
                                                                </ul>
                                                            ) : (
                                                                <p className="ml-4">No visits recorded.</p>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div> */}
                        </div>
                        <div>

                          <h2 className="text-lg font-semibold mb-2 text-gray-700">Previous OPD</h2>

                          {console.log(user)}
                          {user?.opdForms ? (
                            <ul className="list-disc list-inside ml-4">
                              {user?.opdForms.map((opd, idx) => (
                                <li key={idx}>
                                  <Link to={`/dashboard/edit-opd/${opd}`}> {opd}  </Link>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="ml-4">No visits recorded.</p>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex justify-end space-x-4 mt-6">
                          {/* <button
                                                    className="flex items-center bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none"
                                                    onClick={() => handleOPDCreate(user)}
                                                >
                                                    <FaEdit className="mr-2" />
                                                    Create OPD
                                                </button> */}
                          {/* <button
                                                    className="flex items-center bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none"
                                                    onClick={() => handleEdit(user._id)}
                                                >
                                                    <FaEdit className="mr-2" />
                                                    Edit
                                                </button>
                                                <button
                                                    className="flex items-center bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600 focus:outline-none"
                                                    onClick={() => handleDelete(user._id)}
                                                >
                                                    <FaTrash className="mr-2" />
                                                    Delete
                                                </button> */}
                          <AnimatePresence>
                            {expandedTiles[user._id] && (
                              <motion.div
                                className="px-4 pb-4"
                                initial="collapsed"
                                animate="expanded"
                                exit="collapsed"
                                variants={{
                                  collapsed: { height: 0, opacity: 0, overflow: 'hidden' },
                                  expanded: { height: 'auto', opacity: 1 },
                                }}
                              >
                                <div className="flex justify-end mt-4">
                                  <button
                                    className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 focus:outline-none"
                                    onClick={() => openModal(user)}
                                  >
                                    Create OPD
                                  </button>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>

                        {/* Modal */}
                        {isModalOpen && selectedUser && selectedUser._id === user._id && (
                          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                            <div className="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
                              <h2 className="text-xl font-semibold mb-4">Create OPD for {selectedUser.userDetails?.name}</h2>
                              
                              {/* Display Age */}
                              <div className="mb-4">
                                <span className="font-medium">Age:</span> {age !== 'N/A' ? age : 'Not Available'}
                              </div>
                              
                              {/* Chief Complaint */}
                              <textarea
                                value={checkupInfo}
                                onChange={(e) => setCheckupInfo(e.target.value)}
                                placeholder="Describe the chief complaint..."
                                className="w-full h-24 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              ></textarea>
                              
                              {/* Action Buttons */}
                              <div className="flex justify-end space-x-4 mt-4">
                                <button
                                  className="bg-gray-300 px-4 py-2 rounded-md hover:bg-gray-400 focus:outline-none"
                                  onClick={closeModal}
                                >
                                  Cancel
                                </button>
                                <button
                                  className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 focus:outline-none"
                                  onClick={handleSubmit}
                                >
                                  Submit
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))
          ) : (
            <div className="text-center text-gray-600">No users found matching your search.</div>
          )}
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default UserList;
