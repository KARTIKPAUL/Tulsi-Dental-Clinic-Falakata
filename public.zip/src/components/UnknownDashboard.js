import React from 'react';

  


const UnknownDashboard = () => {
  return (
    <div>
      <h1 className='text-3xl font-bold underline'>Unkown User Dashboard</h1>
      <p>Welcome, user! Here is your personalized dashboard.</p>
    </div>
  );
};

export default UnknownDashboard;
